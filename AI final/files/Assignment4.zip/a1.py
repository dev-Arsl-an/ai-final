import string
import math

#-----------------------------------------
# Preprocessing function
#-----------------------------------------
def preprocess(text):
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    return text.split()

# Training dataset
positive_docs = ["I love this food", "This movie is great", "Amazing experience"]
negative_docs = ["I hate this taste", "The movie was bad", "Worst experience ever"]

train_docs = {
    "Positive": positive_docs,
    "Negative": negative_docs
}

#-----------------------------------------
# Build Vocabulary
#-----------------------------------------
vocabulary = set()
for cls in train_docs:
    for doc in train_docs[cls]:
        vocabulary.update(preprocess(doc))
vocabulary = sorted(list(vocabulary))

print("Vocabulary:", vocabulary, "\n")

#-----------------------------------------
# Count words per class
#-----------------------------------------
word_counts = {"Positive": {}, "Negative": {}}
class_word_totals = {"Positive": 0, "Negative": 0}

for cls in train_docs:
    for word in vocabulary:
        word_counts[cls][word] = 0

    for doc in train_docs[cls]:
        for word in preprocess(doc):
            word_counts[cls][word] += 1
            class_word_totals[cls] += 1

#-----------------------------------------
# Prior Probabilities
#-----------------------------------------
total_docs = len(positive_docs) + len(negative_docs)
priors = {
    "Positive": len(positive_docs) / total_docs,
    "Negative": len(negative_docs) / total_docs
}

print("Priors:")
print(priors, "\n")

#-----------------------------------------
# Likelihoods with Laplace smoothing
#-----------------------------------------
likelihoods = {"Positive": {}, "Negative": {}}

for cls in word_counts:
    for word in vocabulary:
        likelihoods[cls][word] = (word_counts[cls][word] + 1) / (class_word_totals[cls] + len(vocabulary))

print("Likelihood Table:")
for cls in likelihoods:
    print("\nClass:", cls)
    for word in likelihoods[cls]:
        print(f"P({word}|{cls}) = {likelihoods[cls][word]:.4f}")

#-----------------------------------------
# Classification Function
#-----------------------------------------
def classify(document):
    tokens = preprocess(document)
    scores = {}

    for cls in priors:
        score = math.log(priors[cls])
        for word in tokens:
            if word in vocabulary:
                score += math.log(likelihoods[cls][word])
        scores[cls] = score
    return scores

# Test documents
test_docs = [
    "I love this movie",
    "This was the worst food",
    "Amazing and great experience"
]

print("\n\nPredictions:")
for doc in test_docs:
    probs = classify(doc)
    print("\nDocument:", doc)
    print("Scores:", probs)
    print("Predicted Class:", max(probs, key=probs.get))
